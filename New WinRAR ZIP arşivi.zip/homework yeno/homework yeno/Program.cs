﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework_yeno
{
    class Program
    {
        static void Main(string[] args)
        {



            //qrup yaratmaq

            Console.WriteLine("nece eded qrup lazimdir?");

            int countOfGroup = int.Parse(Console.ReadLine());
            Group[] grouplist = new Group[countOfGroup];

            for (int i = 0; i < countOfGroup; i++)
            {
                grouplist[i] = new Group();

                Console.WriteLine($"{i + 1} ci qrupun adini daxil edin:");
                string groupName = Console.ReadLine();

                grouplist[i].GroupName = groupName;
                grouplist[i].GroupId = Group._idcountgroup;

                Console.WriteLine(grouplist[i].GroupId);




                ///telebeler

                Console.WriteLine("nece telebeden ibaret siyahi lazimdir?");

                int studentOfCount = int.Parse(Console.ReadLine());

                Student[] studentOfList = new Student[studentOfCount];


                for (int j = 0; j < studentOfCount; j++)

                {
                    Console.WriteLine($"{j + 1}-ci telebenin adini daxil edin");


                    string name = Console.ReadLine();




                    studentOfList[j] = new Student(name);



                    studentOfList[j].Firstname = name;

                    Console.WriteLine($"{j + 1}-ci telebenin soyadini daxil edin:");

                    string lastname = Console.ReadLine();
                    studentOfList[j].Lastname = lastname;
                    studentOfList[j].GroupId = grouplist[i].GroupId;
                    Console.WriteLine(studentOfList[j].GroupId);
                    Console.WriteLine(studentOfList[j].StudentId);


                }

                Console.WriteLine("sizin telebeler siyahiniz asagidakidir");

                for (int j = 0; j < studentOfCount; j++)
                {
                    Console.WriteLine($"{studentOfList[j].Firstname}- {studentOfList[j].Lastname}");
                }




                Console.Write("\nPlease, input search name: ");
                string searchName = Console.ReadLine();

                int counter = 0;
                for (int a = 0; a < studentOfCount; a++)
                {
                    if (studentOfList [a].Firstname.ToLower().Contains(searchName.ToLower()))
                    {
                        counter++;
                        Console.WriteLine($"Found: telebenin adi: { studentOfList[a].Firstname} telebenin idsi: {studentOfList[a].StudentId} qrup idsi: {studentOfList[a].GroupId}   qrupun adi: {grouplist[i].GroupName} ");
                    }
                }

                if (counter == 0) Console.WriteLine("404 - Not found");











            }





        }

        class Student
        {

            static Student()
            {
                _idcounter = 1000;
            }
            public Student(string firstname)
            {
                Firstname = firstname;
                StudentId = _idcounter++;


            }
            
            public Student(string fname, int groupid) : this(fname)

            {
                GroupId = groupid;
            }

            public string Firstname { get; set; }
            public string Lastname { get; set; }

            public int StudentId { get; set; }

            public static int _idcounter;

            public int GroupId { get; set; }
        }

        class Group
        {
            static Group()
            {
                _idcountgroup = 0;

            }
            public Group()
            {
                GroupId = _idcountgroup++;
            }

            public static int _idcountgroup;
            public string GroupName { get; set; }

            public int GroupId { get; set; }

        }
    }
}
